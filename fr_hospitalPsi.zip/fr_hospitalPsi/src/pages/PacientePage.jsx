import React from 'react'
import PacienteComponente from '../components/paciente/PacienteComponente'

export default function PacientePage() {
  return (
    <div>
      <PacienteComponente/>
    </div>
  )
}
