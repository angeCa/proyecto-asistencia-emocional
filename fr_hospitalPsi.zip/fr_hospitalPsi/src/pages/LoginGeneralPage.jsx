import React from 'react'
import LoginGeneral from '../components/login/LoginGeneral'

function LoginGeneralPage() {
  return (
    <div>
      <LoginGeneral/>
    </div>
  )
}

export default LoginGeneralPage
