import Foro from "../components/foro/Foro";

function ForoPage() {
  return <Foro />;
}

export default ForoPage;
