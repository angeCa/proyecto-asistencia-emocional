import React from 'react'
import RegistroPsicologo from '../components/registroPsicologo/RegistroPsicologo'

export default function RegistroPsicologos() {
  return (
    <div>
      <RegistroPsicologo/>
    </div>
  )
}
