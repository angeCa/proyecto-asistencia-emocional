import React from 'react'
import Nosotros from '../components/nosotros/Nosotros'

export default function NosotrosPage() {
  return (
    <div>
      <Nosotros/>
    </div>
  )
}
