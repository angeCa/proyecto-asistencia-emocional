import React from 'react'
import ComponentePrincipal from '../components/inicio/ComponentePrincipal'

function PaginaPrincipalPage() {
  return (
    <div>
      <ComponentePrincipal/>
    </div>
  )
}

export default PaginaPrincipalPage
