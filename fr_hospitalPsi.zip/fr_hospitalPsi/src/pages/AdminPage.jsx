import React from 'react'
import AdminComponente from '../components/admin/AdminComponente'

export default function AdminPage() {
  return (
    <div>
      <AdminComponente/>
    </div>
  )
}
