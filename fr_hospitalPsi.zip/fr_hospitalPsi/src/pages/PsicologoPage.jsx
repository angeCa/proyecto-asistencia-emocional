import React from 'react'
import PsicologoComponente from '../components/psicologo/PsicologoComponente'

export default function PsicologoPage() {
  return (
    <div>
      <PsicologoComponente/>
    </div>
  )
}
