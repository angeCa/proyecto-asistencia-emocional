import React from 'react'
import RegisterGeneral from '../components/registro/RegisterGeneral'

function RegistroGeneralPage() {
  return (
    <div>
      <RegisterGeneral/>
    </div>
  )
}

export default RegistroGeneralPage
