import React from 'react'
import RecursosPublicos from '../components/recursos/RecursosPublicos'

function RecursosPage() {
  return (
    <div>
      <RecursosPublicos/>
    </div>
  )
}

export default RecursosPage
