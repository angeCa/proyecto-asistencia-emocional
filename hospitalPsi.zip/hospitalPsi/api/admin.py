from django.contrib import admin
from .models import Psicologo

admin.site.register(Psicologo)

